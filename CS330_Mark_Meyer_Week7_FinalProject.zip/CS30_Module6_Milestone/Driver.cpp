#include <glad/glad.h>
#include <GLFW/glfw3.h>
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#define _USE_MATH_DEFINES
#include <cmath>
#include <vector>

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include <iostream>

/*Shader program Macro*/
#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version " core \n" #Source
#endif


// settings
const int SCR_WIDTH  = 800;
const int SCR_HEIGHT = 600;
const char* const SCR_TITLE = "Mark Meyer's Final Project"; // Macro for window title

// Stores the GL data relative to a given mesh
struct GLMesh
{
    GLuint vao;              // Handle for the vertex array object
    GLuint vbos[2];          // Handles for the vertex buffer objects
    GLuint ebos[6];          // Handles for the element buffer objects
    GLuint nIndices;         // Number of indices of the mesh
    GLuint pyramidIndices;   // Number of pyramid indices
    GLuint bottleIndices;    // Number of bottle indices
    GLuint capIndices;       // Number of bottle cap indices
    GLuint planeIndices;     // Number of plane indices
    GLuint sphereIndices;    // Number of sphere indices
    GLuint cupIndices;  // Number of cylinder indices
};

// Main GLFW window
GLFWwindow* gWindow = nullptr;
// Triangle mesh data
GLMesh gMesh;
// Active index buffer
GLuint activeIndexBuffer = 0;
// Texture scale
glm::vec2 gUVScale(1.0f, 1.0f);
// Shader program
GLuint shaderProgram;
GLuint lampProgram;
// Texture IDs
GLuint uTexture;
GLuint texture1;
GLuint texture2;
GLuint texture3;
GLuint texture4;
GLuint texture5;
GLuint texture6;

// Subject position and scale
glm::vec3 gPosition(0.0f, 0.0f, 0.0f);
glm::vec3 gSpherePosition(-1.0f, -5.5f, 4.0f);
glm::vec3 gCupPosition(-3.0f, -4.5f, 2.0f);
glm::vec3 gScale(1.0f);

// Cube and light color
glm::vec3 gObjectColor(1.0f, 1.0f, 1.0f);
glm::vec3 gLightColor(1.0f, 0.7f, 1.0f);

// Light position and scale
glm::vec3 gLightPosition1(0.0f, 10.0f, 18.0f);
glm::vec3 gLightPosition2(3.0f, 8.0f, 17.0f);
glm::vec3 gLightScale(1.0f);

// Sphere vertices and indices, calculated, printed to console, then copy/pasted pre-formatted into arrays
std::vector<glm::vec3> sphereVertices;
std::vector<int> sphereIndices;

// Cylinder vertices and indices
std::vector<glm::vec3> cupVertices;
std::vector<int> cupIndices;

/* Pyramid Vertex Shader Source Code*/
const GLchar* vertexShaderSource = GLSL(440,

    layout(location = 0) in vec3 position; // VAP position 0 for vertex position data
    layout(location = 1) in vec3 normal; // VAP position 1 for normals
    layout(location = 2) in vec2 textureCoordinate;

    out vec3 vertexNormal; // For outgoing normals to fragment shader
    out vec3 vertexFragmentPos; // For outgoing color / pixels to fragment shader
    out vec2 vertexTextureCoordinate;

    //Uniform / Global variables for the transform matrices
    uniform mat4 model;
    uniform mat4 view;
    uniform mat4 projection;

void main()
{
    gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates

    vertexFragmentPos = vec3(model * vec4(position, 1.0f)); // Gets fragment / pixel position in world space only (exclude view and projection)

    vertexNormal = mat3(transpose(inverse(model))) * normal; // get normal vectors in world space only and exclude normal translation properties
    vertexTextureCoordinate = textureCoordinate;
}
);


/* Cube Fragment Shader Source Code*/
const GLchar* fragmentShaderSource = GLSL(440,

    in vec3 vertexNormal; // For incoming normals
    in vec3 vertexFragmentPos; // For incoming fragment position
    in vec2 vertexTextureCoordinate; // For incoming texture coords

    out vec4 fragmentColor; // For outgoing color to the GPU

    // Uniform / Global variables for object color, light color, light position, and camera/view position
    uniform vec3 objectColor;
    uniform vec3 lightColor;
    uniform vec3 lightPos;
    uniform vec3 viewPosition;
    uniform vec2 uvScale;
    // Create texture uniform variables
    uniform sampler2D texture1;
    uniform sampler2D texture2;
    uniform sampler2D texture3;
    uniform sampler2D texture4;
    uniform sampler2D texture5;
    uniform sampler2D texture6;
    uniform sampler2D uTexture;

void main()
{
    /*Phong lighting model calculations to generate ambient, diffuse, and specular components*/

    //Calculate Ambient lighting*/
    float ambientStrength = 0.4f; // Set ambient or global lighting strength
    vec3 ambient = ambientStrength * lightColor; // Generate ambient light color

    //Calculate Diffuse lighting*/
    vec3 norm = normalize(vertexNormal); // Normalize vectors to 1 unit
    vec3 lightDirection = normalize(lightPos - vertexFragmentPos); // Calculate distance (light direction) between light source and fragments/pixels on cube
    float impact = max(dot(norm, lightDirection), 0.0);// Calculate diffuse impact by generating dot product of normal and light
    vec3 diffuse = impact * lightColor; // Generate diffuse light color

    //Calculate Specular lighting*/
    float specularIntensity = 0.3f; // Set specular light strength
    float highlightSize = 16.0f; // Set specular highlight size
    vec3 viewDir = normalize(viewPosition - vertexFragmentPos); // Calculate view direction
    vec3 reflectDir = reflect(-lightDirection, norm);// Calculate reflection vector
    //Calculate specular component
    float specularComponent = pow(max(dot(viewDir, reflectDir), 0.0), highlightSize);
    vec3 specular = specularIntensity * specularComponent * lightColor;

    // Texture holds the color to be used for all three components
    vec4 textureColor  = texture(uTexture, vertexTextureCoordinate * uvScale);

    // Calculate phong result
    vec3 phong  = (ambient + diffuse + specular) * textureColor.xyz;

    fragmentColor  = vec4(phong, 1.0); // Send lighting results to GPU
}
);

/* Lamp Shader Source Code*/
const GLchar* lampVertexShaderSource = GLSL(440,

    layout(location = 0) in vec3 position; // VAP position 0 for vertex position data

    //Uniform / Global variables for the  transform matrices
    uniform mat4 model;
    uniform mat4 view;
    uniform mat4 projection;

void main()
{
    gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates
}
);

/* Fragment Shader Source Code*/
const GLchar* lampFragmentShaderSource = GLSL(440,

    out vec4 fragmentColor; // For outgoing lamp color (smaller cube) to the GPU

void main()
{
    fragmentColor = vec4(1.0f); // Set color to white (1.0f,1.0f,1.0f) with alpha 1.0
}
);

// camera
glm::vec3 cameraPos = glm::vec3(0.0f, 7.0f, 20.0f);
glm::vec3 cameraFront = glm::vec3(0.0f, 0.0f, -1.0f);
glm::vec3 cameraUp = glm::vec3(0.0f, 1.0f, 0.0f);

GLboolean firstMouse = true;
float yaw = -90.0f;	// yaw is initialized to -90.0 degrees since a yaw of 0.0 results in a direction vector pointing to the right so we initially rotate a bit to the left.
float pitch = 0.0f;
float lastX = (float)SCR_WIDTH / 2.0f;
float lastY = (float)SCR_HEIGHT / 2.0f;
float fov = 45.0f;

// timing
float deltaTime = 0.0f;	// time between current frame and last frame
float lastFrame = 0.0f;


/* User-defined Function prototypes to:
 * initialize the program, set the window size,
 * redraw graphics on the window when resized,
 * and render graphics on the screen
 */
 // System and input device manipulation
bool UInitialize(int argc, char* argv[], GLFWwindow * *window);
void UResizeWindow(GLFWwindow * window, int width, int height);
void UProcessInput(GLFWwindow * window);
void framebuffer_size_callback(GLFWwindow * window, int width, int height);
void mouse_callback(GLFWwindow * window, double xpos, double ypos);
void scroll_callback(GLFWwindow * window, double xoffset, double yoffset);
void processMouseScroll(float yoffset, float deltaTime);
// Scene manipulation
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint & shaderProgram);
void UDestroyShaderProgram(GLuint shaderProgram);
void URender(GLuint shaderProgram);
void UCreateMesh(GLMesh & gMesh);
bool UCreateTexture(const char* imageFile, GLuint & textureId);
void UDrawObjectWithTexture(GLint loc, GLuint & txtrId, GLint ebo, GLuint indices);
void UPassTransformMatrices(glm::mat4 model,
                            glm::mat4 view, 
                            glm::mat4 projection, 
                            glm::vec3 camPos, 
                            GLuint    shader, 
                            glm::vec3 lightPos, 
                            float     lightR, 
                            float     lightG, 
                            float     lightB);
void UPassUniformLampMatrices(glm::mat4 model, glm::mat4 view, glm::mat4 projection, GLuint lampshader);
void USetUniform(GLint loc, GLint unit);
void UBindTexture(GLint loc, GLuint & textureId);
void UCalcSphere(int stacks, int slices, float radius);

// Destruction
void UnbindTexture();
void UDestroyMesh(GLMesh & gMesh);
void UDestroyTexture(GLuint textureId);

// Implements the UCreateMesh function
void UCreateMesh(GLMesh & mesh)
{
    // set up vertex data (and buffer(s)) and configure vertex attributes
    // ------------------------------------------------------------------
    float vertices[] = 
    {
        // Pyramid
        // Vertex Position  //Negative Y Normals  //Textures
        //Base
       -1.0f, -1.5f, -1.0f, 0.0f, -1.5f, 0.0f,   0.0f, 0.0f,   //0
        1.0f, -1.5f, -1.0f, 0.0f, -1.5f, 0.0f,   0.0f, 1.0f,   //1
       -1.0f, -1.5f,  1.0f, 0.0f, -1.5f, 0.0f,   1.0f, 0.0f,   //2
                           //Negative Y Normals                
       -1.0f, -1.5f,  1.0f, 0.0f, -1.5f, 0.0f,   0.0f, 0.0f,   //3
        1.0f, -1.5f, -1.0f, 0.0f, -1.5f, 0.0f,   1.0f, 1.0f,   //4
        1.0f, -1.5f,  1.0f, 0.0f, -1.5f, 0.0f,   1.0f, 0.0f,   //5
        // Faces
        // Front            //Positive Z Normals
        0.0f,  1.5f, 0.0f,  0.0f,  1.0f,  1.0f,   0.5f, 0.5f,  //6
       -1.0f, -1.5f, 1.0f,  0.0f,  1.0f,  1.0f,   0.0f, 0.0f,  //7
        1.0f, -1.5f, 1.0f,  0.0f,  1.0f,  1.0f,   1.0f, 0.0f,  //8
        // Rear             //Negative Z Normals
        0.0f,  1.5f, 0.0f,  0.0f,  1.0f, -1.0f,   0.5f, 0.5f,  //9
       -1.0f, -1.5f,-1.0f,  0.0f,  1.0f, -1.0f,   0.0f, 1.0f,  //10
        1.0f, -1.5f,-1.0f,  0.0f,  1.0f, -1.0f,   1.0f, 1.0f,  //11
        // Left             //Negative X Normals
        0.0f,  1.5f, 0.0f,  -1.0f,  1.0f,  0.0f,  0.5f, 0.5f,  //12
       -1.0f, -1.5f, 1.0f,  -1.0f,  1.0f,  0.0f,  0.0f, 0.0f,  //13
       -1.0f, -1.5f,-1.0f,  -1.0f,  1.0f,  0.0f,  1.0f, 0.0f,  //14
        // Right            //Positive X Normals
        0.0f,  1.5f, 0.0f,  1.0f,  1.0f,  0.0f,   0.5f, 0.5f,  //15
        1.0f, -1.5f,-1.0f,  1.0f,  1.0f,  0.0f,   1.0f, 1.0f,  //16
        1.0f, -1.5f, 1.0f,  1.0f,  1.0f,  0.0f,   0.0f, 1.0f,  //17

        // Rectangular Cube
        // Vertex Positions  //Positive X Normals //Textures
        // front-right face
        1.0f, -1.5f, 1.0f,   1.0f,  0.5f,  0.0f,  1.0f, 1.0f, //18 
        1.0f, -6.5f, 1.0f,   1.0f,  0.5f,  0.0f,  1.0f, 0.0f, //19 
       -1.0f, -1.5f, 1.0f,   1.0f,  0.5f,  0.0f,  0.0f, 1.0f, //20 
       -1.0f, -6.5f, 1.0f,   1.0f,  0.5f,  0.0f,  0.0f, 0.0f, //21 

        // front-left face  //Negative X Normals
       -1.0f, -6.5f, -1.0f, -1.0f,  0.5f,  0.0f,  0.0f, 0.0f, //22 
       -1.0f, -1.5f, -1.0f, -1.0f,  0.5f,  0.0f,  0.0f, 1.0f, //23
       -1.0f, -1.5f, 1.0f,  -1.0f,  0.5f,  0.0f,  1.0f, 1.0f, //24 
       -1.0f, -6.5f, 1.0f,  -1.0f,  0.5f,  0.0f,  1.0f, 0.0f, //25 

        // rear-left face   //Negative X Normals
        1.0f, -1.5f, -1.0f, -1.0f,  0.5f,  0.0f,  0.0f, 1.0f, //26 
        1.0f, -6.5f, -1.0f, -1.0f,  0.5f,  0.0f,  0.0f, 0.0f, //27 
       -1.0f, -6.5f, -1.0f, -1.0f,  0.5f,  0.0f,  1.0f, 0.0f, //28 
       -1.0f, -1.5f, -1.0f, -1.0f,  0.5f,  0.0f,  1.0f, 1.0f, //29 

        // rear-right face   //Positive X Normals
        1.0f, -1.5f, 1.0f,   1.0f,  0.5f,  0.0f,  0.0f, 1.0f, //30 
        1.0f, -6.5f, 1.0f,   1.0f,  0.5f,  0.0f,  0.0f, 0.0f, //31
        1.0f, -6.5f, -1.0f,  1.0f,  0.5f,  0.0f,  1.0f, 0.0f, //32 
        1.0f, -1.5f, -1.0f,  1.0f,  0.5f,  0.0f,  1.0f, 1.0f, //33 

        // bottom of cube
       -1.0f, -6.5f, -1.0f,  0.0f, -6.5f,  0.0f,  1.0f, 0.0f, //34
       -1.0f, -6.5f, 1.0f,   0.0f, -6.5f,  0.0f,  1.0f, 0.0f, //35 
        1.0f, -6.5f, 1.0f,   0.0f, -6.5f,  0.0f,  1.0f, 0.0f, //36 
        1.0f, -6.5f, -1.0f,  0.0f, -6.5f,  0.0f,  1.0f, 0.0f, //37 

        // Cube
        // Vertex Positions  // Normals           // Textures
        // front-right face  //Positive X
        0.25f, 1.7f, 0.25f,  1.0f,  0.5f,  0.0f,  1.0f, 1.0f, //38
        0.25f, 1.2f, 0.25f,  1.0f,  0.5f,  0.0f,  1.0f, 0.0f, //39
       -0.25f, 1.7f, 0.25f,  1.0f,  0.5f,  0.0f,  0.0f, 1.0f, //40
       -0.25f, 1.2f, 0.25f,  1.0f,  0.5f,  0.0f,  0.0f, 0.0f, //41

        // front-left face   //Negative X
       -0.25f, 1.2f, -0.25f, -1.0f, 0.5f, 0.0f,   0.0f, 0.0f, //42
       -0.25f, 1.7f, -0.25f, -1.0f, 0.5f, 0.0f,   0.0f, 1.0f, //43
       -0.25f, 1.7f, 0.25f,  -1.0f, 0.5f, 0.0f,   1.0f, 1.0f, //44
       -0.25f, 1.2f, 0.25f,  -1.0f, 0.5f, 0.0f,   1.0f, 0.0f, //45

        // rear-left face
        0.25f, 1.7f, -0.25f, -1.0f, 0.5f, 0.0f,   0.0f, 1.0f, //46
        0.25f, 1.2f, -0.25f, -1.0f, 0.5f, 0.0f,   0.0f, 0.0f, //47
       -0.25f, 1.2f, -0.25f, -1.0f, 0.5f, 0.0f,   1.0f, 0.0f, //48
       -0.25f, 1.7f, -0.25f, -1.0f, 0.5f, 0.0f,   1.0f, 1.0f, //49

        // rear-right face    //Positive X
        0.25f, 1.7f, 0.25f,   1.0f, 0.5f, 0.0f,   0.0f, 1.0f, //50
        0.25f, 1.2f, 0.25f,   1.0f, 0.5f, 0.0f,   0.0f, 0.0f, //51
        0.25f, 1.2f, -0.25f,  1.0f, 0.5f, 0.0f,   1.0f, 0.0f, //52
        0.25f, 1.7f, -0.25f,  1.0f, 0.5f, 0.0f,   1.0f, 1.0f, //53

        // bottom of cube
       -0.25f, 1.2f, -0.25f,  0.0f, -1.0f, 0.0f,  0.0f, 1.0f, //54
       -0.25f, 1.2f, 0.25f,   0.0f, -1.0f, 0.0f,  0.0f, 0.0f, //55
        0.25f, 1.2f, 0.25f,   0.0f, -1.0f, 0.0f,  1.0f, 0.0f, //56
        0.25f, 1.2f, -0.25f,  0.0f, -1.0f, 0.0f,  1.0f, 1.0f, //57

        // top of cube
       -0.25f, 1.7f, -0.25f,  0.0f, 1.0f, 0.0f,   0.0f, 1.0f, //58
       -0.25f, 1.7f, 0.25f,   0.0f, 1.0f, 0.0f,   0.0f, 0.0f, //59
        0.25f, 1.7f, 0.25f,   0.0f, 1.0f, 0.0f,   1.0f, 0.0f, //60
        0.25f, 1.7f, -0.25f,  0.0f, 1.0f, 0.0f,   1.0f, 1.0f, //61

        // Plane
        // Vertex Positions   // Negative Y       // Textures
       -10.0f, -6.5f, -10.0f, 0.0f, -1.0f, 0.0f,  0.0f, 0.0f, //62
        10.0f, -6.5f, -10.0f, 0.0f, -1.0f, 0.0f,  1.0f, 0.0f, //63
        10.0f, -6.5f, 10.0f,  0.0f, -1.0f, 0.0f,  1.0f, 1.0f, //64
        10.0f, -6.5f, 10.0f,  0.0f, -1.0f, 0.0f,  1.0f, 1.0f, //65
       -10.0f, -6.5f, 10.0f,  0.0f, -1.0f, 0.0f,  0.0f, 1.0f, //66
       -10.0f, -6.5f, -10.0f, 0.0f, -1.0f, 0.0f,  0.0f, 0.0f, //67
        
        // Sphere
        // Vertex Positions                               // Sphere Normals                          // Sphere Texture Coords
                0.0f,          1.0f,          0.0f,            0.0f,          1.0f,          0.0f,        0.5f,       1.0f, //68
                0.0f,          1.0f,          0.0f,            0.0f,          1.0f,          0.0f,        0.5f,       1.0f, //69
                0.0f,          1.0f,          0.0f,            0.0f,          1.0f,          0.0f,        0.5f,       1.0f, //70
                0.0f,          1.0f,          0.0f,            0.0f,          1.0f,          0.0f,        0.5f,       1.0f, //71
                0.0f,          1.0f,          0.0f,            0.0f,          1.0f,          0.0f,        0.5f,       1.0f, //72
                0.0f,          1.0f,          0.0f,            0.0f,          1.0f,          0.0f,        0.5f,       1.0f, //73
                0.0f,          1.0f,          0.0f,            0.0f,          1.0f,          0.0f,        0.5f,       1.0f, //74
                0.0f,          1.0f,          0.0f,            0.0f,          1.0f,          0.0f,        0.5f,       1.0f, //75
                0.0f,          1.0f,          0.0f,            0.0f,          1.0f,          0.0f,        0.5f,       1.0f, //76
                0.0f,          1.0f,          0.0f,            0.0f,          1.0f,          0.0f,        0.5f,       1.0f, //77
                0.0f,          1.0f,          0.0f,            0.0f,          1.0f,          0.0f,        0.5f,       1.0f, //78
           0.309017f,     0.951057f,          0.0f,       0.309017f,     0.951057f,          0.0f,   0.654508f,  0.975528f, //79
               0.25f,     0.951057f,     0.181636f,           0.25f,     0.951057f,     0.181636f,      0.625f,  0.975528f, //80
          0.0954915f,     0.951057f,     0.293893f,      0.0954915f,     0.951057f,     0.293893f,   0.547746f,  0.975528f, //81
         -0.0954916f,     0.951057f,     0.293893f,     -0.0954916f,     0.951057f,     0.293893f,   0.452254f,  0.975528f, //82
              -0.25f,     0.951057f,     0.181636f,          -0.25f,     0.951057f,     0.181636f,      0.375f,  0.975528f, //83
          -0.309017f,     0.951057f, -2.70151e-08f,      -0.309017f,     0.951057f, -2.70151e-08f,   0.345491f,  0.975528f, //84
              -0.25f,     0.951057f,    -0.181636f,          -0.25f,     0.951057f,    -0.181636f,      0.375f,  0.975528f, //85
         -0.0954915f,     0.951057f,    -0.293893f,     -0.0954915f,     0.951057f,    -0.293893f,   0.452254f,  0.975528f, //86
          0.0954915f,     0.951057f,    -0.293893f,      0.0954915f,     0.951057f,    -0.293893f,   0.547746f,  0.975528f, //87
               0.25f,     0.951057f,    -0.181636f,           0.25f,     0.951057f,    -0.181636f,      0.625f,  0.975528f, //88
           0.309017f,     0.951057f,  5.40302e-08f,       0.309017f,     0.951057f,  5.40302e-08f,   0.654508f,  0.975528f, //89
           0.587785f,     0.809017f,          0.0f,       0.587785f,     0.809017f,          0.0f,   0.793893f,  0.904508f, //90
           0.475528f,     0.809017f,     0.345491f,       0.475528f,     0.809017f,     0.345491f,   0.737764f,  0.904508f, //91
           0.181636f,     0.809017f,     0.559017f,       0.181636f,     0.809017f,     0.559017f,   0.590818f,  0.904508f, //92
          -0.181636f,     0.809017f,     0.559017f,      -0.181636f,     0.809017f,     0.559017f,   0.409182f,  0.904508f, //93
          -0.475528f,     0.809017f,     0.345491f,      -0.475528f,     0.809017f,     0.345491f,   0.262236f,  0.904508f, //94
          -0.587785f,     0.809017f, -5.13858e-08f,      -0.587785f,     0.809017f, -5.13858e-08f,   0.206107f,  0.904508f, //95
          -0.475528f,     0.809017f,    -0.345492f,      -0.475528f,     0.809017f,    -0.345492f,   0.262236f,  0.904508f, //96
          -0.181636f,     0.809017f,    -0.559017f,      -0.181636f,     0.809017f,    -0.559017f,   0.409182f,  0.904508f, //97
           0.181636f,     0.809017f,    -0.559017f,       0.181636f,     0.809017f,    -0.559017f,   0.590818f,  0.904508f, //98
           0.475528f,     0.809017f,    -0.345492f,       0.475528f,     0.809017f,    -0.345492f,   0.737764f,  0.904508f, //99
           0.587785f,     0.809017f,  1.02772e-07f,       0.587785f,     0.809017f,  1.02772e-07f,   0.793893f,  0.904508f, //100
           0.809017f,     0.587785f,          0.0f,       0.809017f,     0.587785f,          0.0f,   0.904509f,  0.793893f, //101
           0.654509f,     0.587785f,     0.475528f,       0.654509f,     0.587785f,     0.475528f,   0.827254f,  0.793893f, //102
               0.25f,     0.587785f,     0.769421f,           0.25f,     0.587785f,     0.769421f,      0.625f,  0.793893f, //103
              -0.25f,     0.587785f,     0.769421f,          -0.25f,     0.587785f,     0.769421f,      0.375f,  0.793893f, //104
          -0.654509f,     0.587785f,     0.475528f,      -0.654509f,     0.587785f,     0.475528f,   0.172746f,  0.793893f, //105
          -0.809017f,     0.587785f, -7.07265e-08f,      -0.809017f,     0.587785f, -7.07265e-08f,  0.0954915f,  0.793893f, //106
          -0.654508f,     0.587785f,    -0.475529f,      -0.654508f,     0.587785f,    -0.475529f,   0.172746f,  0.793893f, //107
              -0.25f,     0.587785f,    -0.769421f,          -0.25f,     0.587785f,    -0.769421f,      0.375f,  0.793893f, //108
               0.25f,     0.587785f,    -0.769421f,           0.25f,     0.587785f,    -0.769421f,      0.625f,  0.793893f, //109
           0.654509f,     0.587785f,    -0.475528f,       0.654509f,     0.587785f,    -0.475528f,   0.827254f,  0.793893f, //110
           0.809017f,     0.587785f,  1.41453e-07f,       0.809017f,     0.587785f,  1.41453e-07f,   0.904509f,  0.793893f, //111
           0.951057f,     0.309017f,          0.0f,       0.951057f,     0.309017f,          0.0f,   0.975528f,  0.654508f, //112
           0.769421f,     0.309017f,     0.559017f,       0.769421f,     0.309017f,     0.559017f,    0.88471f,  0.654508f, //113
           0.293893f,     0.309017f,     0.904509f,       0.293893f,     0.309017f,     0.904509f,   0.646946f,  0.654508f, //114
          -0.293893f,     0.309017f,     0.904508f,      -0.293893f,     0.309017f,     0.904508f,   0.353054f,  0.654508f, //115
          -0.769421f,     0.309017f,     0.559017f,      -0.769421f,     0.309017f,     0.559017f,    0.11529f,  0.654508f, //116
          -0.951057f,     0.309017f,  -8.3144e-08f,      -0.951057f,     0.309017f,  -8.3144e-08f,  0.0244717f,  0.654508f, //117
          -0.769421f,     0.309017f,    -0.559017f,      -0.769421f,     0.309017f,    -0.559017f,    0.11529f,  0.654508f, //118
          -0.293893f,     0.309017f,    -0.904508f,      -0.293893f,     0.309017f,    -0.904508f,   0.353054f,  0.654508f, //119
           0.293893f,     0.309017f,    -0.904508f,       0.293893f,     0.309017f,    -0.904508f,   0.646946f,  0.654508f, //120
           0.769421f,     0.309017f,    -0.559017f,       0.769421f,     0.309017f,    -0.559017f,    0.88471f,  0.654508f, //121
           0.951057f,     0.309017f,  1.66288e-07f,       0.951057f,     0.309017f,  1.66288e-07f,   0.975528f,  0.654508f, //122
                1.0f, -4.37114e-08f,          0.0f,            1.0f, -4.37114e-08f,          0.0f,        1.0f,       0.5f, //123
           0.809017f, -4.37114e-08f,     0.587785f,       0.809017f, -4.37114e-08f,     0.587785f,   0.904508f,       0.5f, //124
           0.309017f, -4.37114e-08f,     0.951057f,       0.309017f, -4.37114e-08f,     0.951057f,   0.654508f,       0.5f, //125
          -0.309017f, -4.37114e-08f,     0.951056f,      -0.309017f, -4.37114e-08f,     0.951056f,   0.345491f,       0.5f, //126
          -0.809017f, -4.37114e-08f,     0.587785f,      -0.809017f, -4.37114e-08f,     0.587785f,  0.0954915f,       0.5f, //127
               -1.0f, -4.37114e-08f, -8.74228e-08f,           -1.0f, -4.37114e-08f, -8.74228e-08f,        0.0f,       0.5f, //128
          -0.809017f, -4.37114e-08f,    -0.587786f,      -0.809017f, -4.37114e-08f,    -0.587786f,  0.0954916f,       0.5f, //129
          -0.309017f, -4.37114e-08f,    -0.951056f,      -0.309017f, -4.37114e-08f,    -0.951056f,   0.345491f,       0.5f, //130
           0.309017f, -4.37114e-08f,    -0.951056f,       0.309017f, -4.37114e-08f,    -0.951056f,   0.654509f,       0.5f, //131
           0.809017f, -4.37114e-08f,    -0.587785f,       0.809017f, -4.37114e-08f,    -0.587785f,   0.904508f,       0.5f, //132
                1.0f, -4.37114e-08f,  1.74846e-07f,            1.0f, -4.37114e-08f,  1.74846e-07f,        1.0f,       0.5f, //133
           0.951056f,    -0.309017f,          0.0f,       0.951056f,    -0.309017f,          0.0f,   0.975528f,  0.345491f, //134
           0.769421f,    -0.309017f,     0.559017f,       0.769421f,    -0.309017f,     0.559017f,    0.88471f,  0.345491f, //135
           0.293893f,    -0.309017f,     0.904508f,       0.293893f,    -0.309017f,     0.904508f,   0.646946f,  0.345491f, //136
          -0.293893f,    -0.309017f,     0.904508f,      -0.293893f,    -0.309017f,     0.904508f,   0.353054f,  0.345491f, //137
          -0.769421f,    -0.309017f,     0.559017f,      -0.769421f,    -0.309017f,     0.559017f,    0.11529f,  0.345491f, //138
          -0.951056f,    -0.309017f,  -8.3144e-08f,      -0.951056f,    -0.309017f,  -8.3144e-08f,  0.0244718f,  0.345491f, //139
          -0.769421f,    -0.309017f,    -0.559017f,      -0.769421f,    -0.309017f,    -0.559017f,    0.11529f,  0.345491f, //140
          -0.293893f,    -0.309017f,    -0.904508f,      -0.293893f,    -0.309017f,    -0.904508f,   0.353054f,  0.345491f, //141
           0.293893f,    -0.309017f,    -0.904508f,       0.293893f,    -0.309017f,    -0.904508f,   0.646946f,  0.345491f, //142
           0.769421f,    -0.309017f,    -0.559017f,       0.769421f,    -0.309017f,    -0.559017f,    0.88471f,  0.345491f, //143
           0.951056f,    -0.309017f,  1.66288e-07f,       0.951056f,    -0.309017f,  1.66288e-07f,   0.975528f,  0.345491f, //144
           0.809017f,    -0.587785f,          0.0f,       0.809017f,    -0.587785f,          0.0f,   0.904508f,  0.206107f, //145
           0.654509f,    -0.587785f,     0.475528f,       0.654509f,    -0.587785f,     0.475528f,   0.827254f,  0.206107f, //146
               0.25f,    -0.587785f,     0.769421f,           0.25f,    -0.587785f,     0.769421f,      0.625f,  0.206107f, //147
              -0.25f,    -0.587785f,     0.769421f,          -0.25f,    -0.587785f,     0.769421f,      0.375f,  0.206107f, //148
          -0.654509f,    -0.587785f,     0.475528f,      -0.654509f,    -0.587785f,     0.475528f,   0.172746f,  0.206107f, //149
          -0.809017f,    -0.587785f, -7.07265e-08f,      -0.809017f,    -0.587785f, -7.07265e-08f,  0.0954915f,  0.206107f, //150
          -0.654508f,    -0.587785f,    -0.475529f,      -0.654508f,    -0.587785f,    -0.475529f,   0.172746f,  0.206107f, //151
              -0.25f,    -0.587785f,    -0.769421f,          -0.25f,    -0.587785f,    -0.769421f,      0.375f,  0.206107f, //152
               0.25f,    -0.587785f,    -0.769421f,           0.25f,    -0.587785f,    -0.769421f,      0.625f,  0.206107f, //153
           0.654508f,    -0.587785f,    -0.475528f,       0.654508f,    -0.587785f,    -0.475528f,   0.827254f,  0.206107f, //154
           0.809017f,    -0.587785f,  1.41453e-07f,       0.809017f,    -0.587785f,  1.41453e-07f,   0.904508f,  0.206107f, //155
           0.587785f,    -0.809017f,          0.0f,       0.587785f,    -0.809017f,          0.0f,   0.793893f, 0.0954915f, //156
           0.475528f,    -0.809017f,     0.345491f,       0.475528f,    -0.809017f,     0.345491f,   0.737764f, 0.0954915f, //157
           0.181636f,    -0.809017f,     0.559017f,       0.181636f,    -0.809017f,     0.559017f,   0.590818f, 0.0954915f, //158
          -0.181636f,    -0.809017f,     0.559017f,      -0.181636f,    -0.809017f,     0.559017f,   0.409182f, 0.0954915f, //159
          -0.475528f,    -0.809017f,     0.345491f,      -0.475528f,    -0.809017f,     0.345491f,   0.262236f, 0.0954915f, //160
          -0.587785f,    -0.809017f, -5.13858e-08f,      -0.587785f,    -0.809017f, -5.13858e-08f,   0.206107f, 0.0954915f, //161
          -0.475528f,    -0.809017f,    -0.345492f,      -0.475528f,    -0.809017f,    -0.345492f,   0.262236f, 0.0954915f, //162
          -0.181636f,    -0.809017f,    -0.559017f,      -0.181636f,    -0.809017f,    -0.559017f,   0.409182f, 0.0954915f, //163
           0.181636f,    -0.809017f,    -0.559017f,       0.181636f,    -0.809017f,    -0.559017f,   0.590818f, 0.0954915f, //164
           0.475528f,    -0.809017f,    -0.345491f,       0.475528f,    -0.809017f,    -0.345491f,   0.737764f, 0.0954915f, //165
           0.587785f,    -0.809017f,  1.02772e-07f,       0.587785f,    -0.809017f,  1.02772e-07f,   0.793893f, 0.0954915f, //166
           0.309017f,    -0.951056f,          0.0f,       0.309017f,    -0.951056f,          0.0f,   0.654509f, 0.0244718f, //167
               0.25f,    -0.951056f,     0.181636f,           0.25f,    -0.951056f,     0.181636f,      0.625f, 0.0244718f, //168
          0.0954915f,    -0.951056f,     0.293893f,      0.0954915f,    -0.951056f,     0.293893f,   0.547746f, 0.0244718f, //169
         -0.0954916f,    -0.951056f,     0.293893f,     -0.0954916f,    -0.951056f,     0.293893f,   0.452254f, 0.0244718f, //170
              -0.25f,    -0.951056f,     0.181636f,          -0.25f,    -0.951056f,     0.181636f,      0.375f, 0.0244718f, //171
          -0.309017f,    -0.951056f, -2.70151e-08f,      -0.309017f,    -0.951056f, -2.70151e-08f,   0.345491f, 0.0244718f, //172
              -0.25f,    -0.951056f,    -0.181636f,          -0.25f,    -0.951056f,    -0.181636f,      0.375f, 0.0244718f, //173
         -0.0954915f,    -0.951056f,    -0.293893f,     -0.0954915f,    -0.951056f,    -0.293893f,   0.452254f, 0.0244718f, //174
          0.0954916f,    -0.951056f,    -0.293893f,      0.0954916f,    -0.951056f,    -0.293893f,   0.547746f, 0.0244718f, //175
               0.25f,    -0.951056f,    -0.181636f,           0.25f,    -0.951056f,    -0.181636f,      0.625f, 0.0244718f, //176
           0.309017f,    -0.951056f,  5.40303e-08f,       0.309017f,    -0.951056f,  5.40303e-08f,   0.654509f, 0.0244718f, //177
       -8.74228e-08f,         -1.0f,          0.0f,   -8.74228e-08f,         -1.0f,          0.0f,        0.5f,       0.0f, //178
       -7.07265e-08f,         -1.0f, -5.13858e-08f,   -7.07265e-08f,         -1.0f, -5.13858e-08f,        0.5f,       0.0f, //179
       -2.70151e-08f,         -1.0f,  -8.3144e-08f,   -2.70151e-08f,         -1.0f,  -8.3144e-08f,        0.5f,       0.0f, //180
        2.70151e-08f,         -1.0f,  -8.3144e-08f,    2.70151e-08f,         -1.0f,  -8.3144e-08f,        0.5f,       0.0f, //181
        7.07265e-08f,         -1.0f, -5.13858e-08f,    7.07265e-08f,         -1.0f, -5.13858e-08f,        0.5f,       0.0f, //182
        8.74228e-08f,         -1.0f,  7.64274e-15f,    8.74228e-08f,         -1.0f,  7.64274e-15f,        0.5f,       0.0f, //183
        7.07265e-08f,         -1.0f,  5.13858e-08f,    7.07265e-08f,         -1.0f,  5.13858e-08f,        0.5f,       0.0f, //184
        2.70151e-08f,         -1.0f,   8.3144e-08f,    2.70151e-08f,         -1.0f,   8.3144e-08f,        0.5f,       0.0f, //185
       -2.70151e-08f,         -1.0f,   8.3144e-08f,   -2.70151e-08f,         -1.0f,   8.3144e-08f,        0.5f,       0.0f, //186
       -7.07265e-08f,         -1.0f,  5.13858e-08f,   -7.07265e-08f,         -1.0f,  5.13858e-08f,        0.5f,       0.0f, //187
       -8.74228e-08f,         -1.0f, -1.52855e-14f,   -8.74228e-08f,         -1.0f, -1.52855e-14f,        0.5f,       0.0f, //188

        // Cup
        // Vertex Positions    //Positive X Normals //Textures
        // front-right face                               
         1.0f,  0.7f,  1.0f,    1.0f,  0.5f, 0.0f,   1.0f, 1.0f, //189 
         1.0f, -2.0f,  1.0f,    1.0f,  0.5f, 0.0f,   1.0f, 0.0f, //190
        -1.0f,  0.7f,  1.0f,    1.0f,  0.5f, 0.0f,   0.0f, 1.0f, //191
        -1.0f, -2.0f,  1.0f,    1.0f,  0.5f, 0.0f,   0.0f, 0.0f, //192
                                                          
        // front-left face     //Negative X Normals
        -1.0f, -2.0f, -1.0f,    -1.0f, 0.5f, 0.0f,   0.0f, 0.0f, //193
        -1.0f, -2.0f, -1.0f,    -1.0f, 0.5f, 0.0f,   0.0f, 1.0f, //194
        -1.0f, -2.0f,  1.0f,    -1.0f, 0.5f, 0.0f,   1.0f, 1.0f, //195
        -1.0f, -2.0f,  1.0f,    -1.0f, 0.5f, 0.0f,   1.0f, 0.0f, //196
                                      
        // rear-left face      
         1.0f,  0.7f, -1.0f,    -1.0f, 0.5f, 0.0f,   0.0f, 1.0f, //197
         1.0f, -2.0f, -1.0f,    -1.0f, 0.5f, 0.0f,   0.0f, 0.0f, //198
        -1.0f, -2.0f, -1.0f,    -1.0f, 0.5f, 0.0f,   1.0f, 0.0f, //199
        -1.0f,  0.7f, -1.0f,    -1.0f, 0.5f, 0.0f,   1.0f, 1.0f, //200
                                      
        // rear-right face     //Positive X Normals
         1.0f,  0.7f,  1.0f,    1.0f,  0.5f, 0.0f,   0.0f, 1.0f, //201
         1.0f, -2.0f,  1.0f,    1.0f,  0.5f, 0.0f,   0.0f, 0.0f, //202
         1.0f, -2.0f, -1.0f,    1.0f,  0.5f, 0.0f,   1.0f, 0.0f, //203
         1.0f,  0.7f, -1.0f,    1.0f,  0.5f, 0.0f,   1.0f, 1.0f, //204
                                                          
        // bottom of cube                          
        -1.0f, -2.0f, -1.0f,    0.0f, -6.5f, 0.0f,   1.0f, 0.0f, //205
        -1.0f, -2.0f,  1.0f,    0.0f, -6.5f, 0.0f,   1.0f, 0.0f, //206
         1.0f, -2.0f,  1.0f,    0.0f, -6.5f, 0.0f,   1.0f, 0.0f, //207
         1.0f, -2.0f, -1.0f,    0.0f, -6.5f, 0.0f,   1.0f, 0.0f, //208

        // front-right face                              
         1.0f,  0.7f,  1.0f,    1.0f,  0.5f, 0.0f,   1.0f, 1.0f, //209 
         1.0f, -2.0f,  1.0f,    1.0f,  0.5f, 0.0f,   1.0f, 0.0f, //210
        -1.0f,  0.7f,  1.0f,    1.0f,  0.5f, 0.0f,   0.0f, 1.0f, //211
        -1.0f, -2.0f,  1.0f,    1.0f,  0.5f, 0.0f,   0.0f, 0.0f, //212
                                                                         
        // front-left face     //Negative X Normals           
        -1.0f, -2.0f, -1.0f,   -1.0f,  0.5f, 0.0f,   0.0f, 0.0f, //213
        -1.0f,  0.7f, -1.0f,   -1.0f,  0.5f, 0.0f,   0.0f, 1.0f, //214
        -1.0f,  0.7f,  1.0f,   -1.0f,  0.5f, 0.0f,   1.0f, 1.0f, //215
        -1.0f, -2.0f,  1.0f,   -1.0f,  0.5f, 0.0f,   1.0f, 0.0f, //216
                                                                         
        // rear-left face                
         1.0f,  0.7f, -1.0f,   -1.0f,  0.5f, 0.0f,   0.0f, 1.0f, //217
         1.0f, -2.0f, -1.0f,   -1.0f,  0.5f, 0.0f,   0.0f, 0.0f, //218
        -1.0f, -2.0f, -1.0f,   -1.0f,  0.5f, 0.0f,   1.0f, 0.0f, //219
        -1.0f,  0.7f, -1.0f,   -1.0f,  0.5f, 0.0f,   1.0f, 1.0f, //220
                                                                         
        // rear-right face     //Positive X Normals           
         1.0f,  0.7f,  1.0f,    1.0f,  0.5f, 0.0f,   0.0f, 1.0f, //221
         1.0f, -2.0f,  1.0f,    1.0f,  0.5f, 0.0f,   0.0f, 0.0f, //222
         1.0f, -2.0f, -1.0f,    1.0f,  0.5f, 0.0f,   1.0f, 0.0f, //223
         1.0f,  0.7f, -1.0f,    1.0f,  0.5f, 0.0f,   1.0f, 1.0f, //224
                                                                         
        // bottom of cube                                         
        -1.0f, -2.0f, -1.0f,    0.0f, -6.5f, 0.0f,   1.0f, 0.0f, //225
        -1.0f, -2.0f,  1.0f,    0.0f, -6.5f, 0.0f,   1.0f, 0.0f, //226
         1.0f, -2.0f,  1.0f,    0.0f, -6.5f, 0.0f,   1.0f, 0.0f, //227
         1.0f, -2.0f, -1.0f,    0.0f, -6.5f, 0.0f,   1.0f, 0.0f, //228
                                    
    };

    // Index data to share position data
    unsigned short pyramidIndices[] = 
    {
        // Pyramid
        0, 1, 2,    // Triangle 1
        3, 4, 5,    // Triangle 2
        6, 7, 8,    // Triangle 3
        9, 10, 11,  // Triangle 4
        12, 13, 14, // Triangle 5
        15, 16, 17  // Triangle 6
    };

    unsigned short bottleIndices[] = 
    {
        // Rectangular Cube
        20, 18, 19, // Triangle 7
        21, 20, 19, // Triangle 8
        22, 24, 25, // Triangle 9
        22, 23, 24, // Triangle 10
        27, 28, 29, // Triangle 11
        26, 27, 29, // Triangle 12
        30, 31, 32, // Triangle 13
        30, 32, 33, // Triangle 14
        34, 35, 36, // Triangle 15
        34, 36, 37  // Triangle 16
    };

    unsigned short capIndices[] =
    {
        // Cube
        40, 38, 39, // Triangle 17
        41, 40, 39, // Triangle 18
        42, 44, 45, // Triangle 19
        42, 43, 44, // Triangle 20
        47, 48, 49, // Triangle 21
        46, 47, 49, // Triangle 22
        50, 51, 52, // Triangle 23
        50, 52, 53, // Triangle 24
        54, 55, 56, // Triangle 25
        54, 56, 57, // Triangle 26
        58, 59, 60, // Triangle 27
        58, 60, 61  // Triangle 28
    };

    unsigned short planeIndices[] =
    {
        // Plane
        62, 65, 66, // Triangle 29
        65, 63, 67  // Triangel 30
    };
    
    unsigned short sphereIndices[] =
    {
        // Sphere
        68, 79, 78,    // Triangle 31
        79, 68, 69,    // Triangle 32
        69, 80, 79,    // Triangle 33
        80, 69, 70,    // Triangle 34
        70, 81, 80,    // Triangle 35
        81, 70, 71,    // Triangle 36
        71, 82, 81,    // Triangle 37
        82, 71, 72,    // Triangle 38
        72, 83, 82,    // Triangle 39
        83, 72, 73,    // Triangle 40
        73, 84, 83,    // Triangle 41
        84, 73, 74,    // Triangle 42
        74, 85, 84,    // Triangle 43
        85, 74, 75,    // Triangle 44
        75, 86, 85,    // Triangle 45
        86, 75, 76,    // Triangle 46
        76, 87, 86,    // Triangle 47
        87, 76, 77,    // Triangle 48
        77, 88, 87,    // Triangle 49
        88, 77, 78,    // Triangle 50
        78, 89, 88,    // Triangle 51
        89, 78, 79,    // Triangle 52
        79, 90, 89,    // Triangle 53
        90, 79, 80,    // Triangle 54
        80, 91, 90,    // Triangle 55
        91, 80, 81,    // Triangle 56
        81, 92, 91,    // Triangle 57
        92, 81, 82,    // Triangle 58
        82, 93, 92,    // Triangle 59
        93, 82, 83,    // Triangle 60
        83, 94, 93,    // Triangle 61
        94, 83, 84,    // Triangle 62
        84, 95, 94,    // Triangle 63
        95, 84, 85,    // Triangle 64
        85, 96, 95,    // Triangle 65
        96, 85, 86,    // Triangle 66
        86, 97, 96,    // Triangle 67
        97, 86, 87,    // Triangle 68
        87, 98, 97,    // Triangle 69
        98, 87, 88,    // Triangle 70
        88, 99, 98,    // Triangle 71
        99, 88, 89,    // Triangle 72
        89, 100, 99,   // Triangle 73
        100, 89, 90,   // Triangle 74
        90, 101, 100,  // Triangle 75
        101, 90, 91,   // Triangle 76
        91, 102, 101,  // Triangle 77
        102, 91, 92,   // Triangle 78
        92, 103, 102,  // Triangle 79
        103, 92, 93,   // Triangle 80
        93, 104, 103,  // Triangle 81
        104, 93, 94,   // Triangle 82
        94, 105, 104,  // Triangle 83
        105, 94, 95,   // Triangle 84
        95, 106, 105,  // Triangle 85
        106, 95, 96,   // Triangle 86
        96, 107, 106,  // Triangle 87
        107, 96, 97,   // Triangle 88
        97, 108, 107,  // Triangle 89
        108, 97, 98,   // Triangle 90
        98, 109, 108,  // Triangle 91
        109, 98, 99,   // Triangle 92
        99, 110, 109,  // Triangle 93
        110, 99, 100,  // Triangle 94
        100, 111, 110, // Triangle 95
        111, 100, 101, // Triangle 96
        101, 112, 111, // Triangle 97
        112, 101, 102, // Triangle 98
        102, 113, 112, // Triangle 99
        113, 102, 103, // Triangle 100
        103, 114, 113, // Triangle 101
        114, 103, 104, // Triangle 102
        104, 115, 114, // Triangle 103
        115, 104, 105, // Triangle 104
        105, 116, 115, // Triangle 105
        116, 105, 106, // Triangle 106
        106, 117, 116, // Triangle 107
        117, 106, 107, // Triangle 108
        107, 118, 117, // Triangle 109
        118, 107, 108, // Triangle 110
        108, 119, 118, // Triangle 111
        119, 108, 109, // Triangle 112
        109, 120, 119, // Triangle 113
        120, 109, 110, // Triangle 114
        110, 121, 120, // Triangle 115
        121, 110, 111, // Triangle 116
        111, 122, 121, // Triangle 117
        122, 111, 112, // Triangle 118
        112, 123, 122, // Triangle 119
        123, 112, 113, // Triangle 120
        113, 124, 123, // Triangle 121
        124, 113, 114, // Triangle 122
        114, 125, 124, // Triangle 123
        125, 114, 115, // Triangle 124
        115, 126, 125, // Triangle 125
        126, 115, 116, // Triangle 126
        116, 127, 126, // Triangle 127
        127, 116, 117, // Triangle 128
        117, 128, 127, // Triangle 129
        128, 117, 118, // Triangle 130
        118, 129, 128, // Triangle 131
        129, 118, 119, // Triangle 132
        119, 130, 129, // Triangle 133
        130, 119, 120, // Triangle 134
        120, 131, 130, // Triangle 135
        131, 120, 121, // Triangle 136
        121, 132, 131, // Triangle 137
        132, 121, 122, // Triangle 138
        122, 133, 132, // Triangle 139
        133, 122, 123, // Triangle 140
        123, 134, 133, // Triangle 141
        134, 123, 124, // Triangle 142
        124, 135, 134, // Triangle 143
        135, 124, 125, // Triangle 144
        125, 136, 135, // Triangle 145
        136, 125, 126, // Triangle 146
        126, 137, 136, // Triangle 147
        137, 126, 127, // Triangle 148
        127, 138, 137, // Triangle 149
        138, 127, 128, // Triangle 150
        128, 139, 138, // Triangle 151
        139, 128, 129, // Triangle 152
        129, 140, 139, // Triangle 153
        140, 129, 130, // Triangle 154
        130, 141, 140, // Triangle 155
        141, 130, 131, // Triangle 156
        131, 142, 141, // Triangle 157
        142, 131, 132, // Triangle 158
        132, 143, 142, // Triangle 159
        143, 132, 133, // Triangle 160
        133, 144, 143, // Triangle 161
        144, 133, 134, // Triangle 162
        134, 145, 144, // Triangle 163
        145, 134, 135, // Triangle 164
        135, 146, 145, // Triangle 165
        146, 135, 136, // Triangle 166
        136, 147, 146, // Triangle 167
        147, 136, 137, // Triangle 168
        137, 148, 147, // Triangle 169
        148, 137, 138, // Triangle 170
        138, 149, 148, // Triangle 171
        149, 138, 139, // Triangle 172
        139, 150, 149, // Triangle 173
        150, 139, 140, // Triangle 174
        140, 151, 150, // Triangle 175
        151, 140, 141, // Triangle 176
        141, 152, 151, // Triangle 177
        152, 141, 142, // Triangle 178
        142, 153, 152, // Triangle 179
        153, 142, 143, // Triangle 180
        143, 154, 153, // Triangle 181
        154, 143, 144, // Triangle 182
        144, 155, 154, // Triangle 183
        155, 144, 145, // Triangle 184
        145, 156, 155, // Triangle 185
        156, 145, 146, // Triangle 186
        146, 157, 156, // Triangle 187
        157, 146, 147, // Triangle 188
        147, 158, 157, // Triangle 189
        158, 147, 148, // Triangle 190
        148, 159, 158, // Triangle 191
        159, 148, 149, // Triangle 192
        149, 160, 159, // Triangle 193
        160, 149, 150, // Triangle 194
        150, 161, 160, // Triangle 195
        161, 150, 151, // Triangle 196
        151, 162, 161, // Triangle 197
        162, 151, 152, // Triangle 198
        152, 163, 162, // Triangle 199
        163, 152, 153, // Triangle 200
        153, 164, 163, // Triangle 201
        164, 153, 154, // Triangle 202
        154, 165, 164, // Triangle 203
        165, 154, 155, // Triangle 204
        155, 166, 165, // Triangle 205
        166, 155, 156, // Triangle 206
        156, 167, 166, // Triangle 207
        167, 156, 157, // Triangle 208
        157, 168, 167, // Triangle 209
        168, 157, 158, // Triangle 210
        158, 169, 168, // Triangle 211
        169, 158, 159, // Triangle 212
        159, 170, 169, // Triangle 213
        170, 159, 160, // Triangle 214
        160, 171, 170, // Triangle 215
        171, 160, 161, // Triangle 216
        161, 172, 171, // Triangle 217
        172, 161, 162, // Triangle 218
        162, 173, 172, // Triangle 219
        173, 162, 163, // Triangle 220
        163, 174, 173, // Triangle 221
        174, 163, 164, // Triangle 222
        164, 175, 174, // Triangle 223
        175, 164, 165, // Triangle 224
        165, 176, 175, // Triangle 225
        176, 165, 166, // Triangle 226
        166, 177, 176, // Triangle 227
        177, 166, 167, // Triangle 228
        167, 178, 177, // Triangle 229
        178, 167, 168, // Triangle 230
        168, 179, 178, // Triangle 240
        179, 168, 169, // Triangle 241
        169, 180, 179, // Triangle 242
        180, 169, 170, // Triangle 243
        170, 181, 180, // Triangle 244
        181, 170, 171, // Triangle 245
        171, 182, 181, // Triangle 246
        182, 171, 172, // Triangle 247
        172, 183, 182, // Triangle 248
        183, 172, 173, // Triangle 249
        173, 184, 183, // Triangle 250
        184, 173, 174, // Triangle 251
        174, 185, 184, // Triangle 252
        185, 174, 175, // Triangle 253
        175, 186, 185, // Triangle 254
        186, 175, 176, // Triangle 255
        176, 187, 186, // Triangle 256
        187, 176, 177, // Triangle 257
        177, 188, 187, // Triangle 258
        188, 177, 178  // Triangle 259
    };
    
    unsigned short cupIndices[] = {
        191, 189, 190, // Triangle 260
        192, 191, 190, // Triangle 261
        193, 195, 196, // Triangle 262
        193, 194, 195, // Triangle 263
        198, 199, 200, // Triangle 264
        197, 198, 200, // Triangle 265
        201, 202, 203, // Triangle 266
        201, 203, 204, // Triangle 267
        205, 206, 207, // Triangle 268
        205, 207, 208, // Triangle 269
                         
        211, 209, 210, // Triangle 270
        212, 211, 210, // Triangle 271
        213, 215, 216, // Triangle 272
        213, 214, 215, // Triangle 273
        218, 219, 220, // Triangle 274
        217, 218, 220, // Triangle 275
        221, 222, 223, // Triangle 276
        221, 223, 224, // Triangle 277
        225, 226, 227, // Triangle 278
        225, 227, 228  // Triangle 279

    };

    // Calculate vertices and indices for sphere (used to calculate contents of sphere vertices and indices but not needed at runtime)
    //UCalcSphere(10, 10, 1.0f);


    GLenum ErrorCheckValue = glGetError();
    // Vertex coordinates
    const unsigned int floatsPerVertex = 3;
    // Normal coordinates for lighting
    const unsigned int floatsPerNormal = 3;
    // Texture coordinates
    const unsigned int floatsPerTexture = 2;
    // Define buffer with all vertices in scene
    const size_t bufferSize = sizeof(vertices);
    // Strides between vertex coordinates is 8 (x, y, z, x, y, z, s, t). A tightly packed stride is 0.
    int stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerTexture);// The number of floats before each

    gMesh.pyramidIndices  = sizeof(pyramidIndices) / sizeof(pyramidIndices[0]);
    gMesh.bottleIndices   = sizeof(bottleIndices)  / sizeof(bottleIndices[0]);
    gMesh.capIndices      = sizeof(capIndices)     / sizeof(capIndices[0]);
    gMesh.planeIndices    = sizeof(planeIndices)   / sizeof(planeIndices[0]);
    gMesh.sphereIndices   = sizeof(sphereIndices)  / sizeof(sphereIndices[0]);
    gMesh.cupIndices = sizeof(cupIndices) / sizeof(cupIndices[0]);

    glGenVertexArrays(1, &gMesh.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(gMesh.vao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(2, gMesh.vbos);

    glBindBuffer(GL_ARRAY_BUFFER, gMesh.vbos[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, bufferSize, vertices, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    // Create 4 buffers: one for each object defined by indices
    glGenBuffers(6, gMesh.ebos);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, gMesh.ebos[0]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(pyramidIndices), pyramidIndices, GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, gMesh.ebos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(bottleIndices), bottleIndices, GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, gMesh.ebos[2]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(capIndices), capIndices, GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, gMesh.ebos[3]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(planeIndices), planeIndices, GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, gMesh.ebos[4]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(sphereIndices), sphereIndices, GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, gMesh.ebos[5]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(cupIndices), cupIndices, GL_STATIC_DRAW);

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerTexture, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);

    ErrorCheckValue = glGetError();
    if (ErrorCheckValue != GL_NO_ERROR)
    {
        std::cout << "ERROR: Could not create a VBO: " << ErrorCheckValue << std::endl;

        exit(-1);
    }

    glBindVertexArray(0);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
}


// load image, create texture and generate mipmaps
bool UCreateTexture(const char* imageFile, GLuint & textureId)
{
    int width, height, nrChannels;

    unsigned char* image = stbi_load(imageFile, &width, &height, &nrChannels, 0);

    // texture
    // ---------
    glGenTextures(1, &textureId);
    // bind textures on corresponding texture units
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, textureId);
    // set texture filtering parameters
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    // set the texture wrapping parameters
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

    if (image)
    {
        stbi_set_flip_vertically_on_load(true); // tell stb_image.h to flip loaded texture's on the y-axis.
        if (nrChannels == 3)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
        else if (nrChannels == 4)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
        else
        {
            std::cout << "Not implemented to handle image with " << nrChannels << " channels" << std::endl;
            return false;
        }

        glGenerateMipmap(GL_TEXTURE_2D);
    }
    else
    {
        std::cout << "Failed to load texture" << std::endl;
    }

    stbi_image_free(image);

    UnbindTexture();

    return true;
}


// Implements the UCreateShaders function
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint & shaderProgram)
{
    // build and compile our shader program
       // ------------------------------------

       // vertex shader
    unsigned int vertexShader = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(vertexShader, 1, &vertexShaderSource, NULL);
    glCompileShader(vertexShader);
    // check for shader compile errors
    int success;
    char infoLog[512];
    glGetShaderiv(vertexShader, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(vertexShader, 512, NULL, infoLog);
        std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    // fragment shader
    unsigned int fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(fragmentShader, 1, &fragmentShaderSource, NULL);
    glCompileShader(fragmentShader);
    // check for shader compile errors
    glGetShaderiv(fragmentShader, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(fragmentShader, 512, NULL, infoLog);
        std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    // link shaders
    shaderProgram = glCreateProgram();
    glAttachShader(shaderProgram, vertexShader);
    glAttachShader(shaderProgram, fragmentShader);
    glLinkProgram(shaderProgram);
    // check for linking errors
    glGetProgramiv(shaderProgram, GL_LINK_STATUS, &success);
    if (!success) 
    {
        glGetProgramInfoLog(shaderProgram, 512, NULL, infoLog);
        std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;

        return false;
    }

    // activate shader
    glUseProgram(shaderProgram);

    return true;
}

// destroy shader
void UDestroyShaderProgram(GLuint shaderProgram)
{
    glDeleteProgram(shaderProgram);
}

// destroy texture
void UDestroyTexture(GLuint textureId)
{
    glGenTextures(1, &textureId);
}

// destroy mesh
void UDestroyMesh(GLMesh & mesh)
{
    glDeleteVertexArrays(1, &mesh.vao);
    glDeleteBuffers(2, mesh.vbos);
}


int main(int argc, char* argv[])
{
    if (!UInitialize(argc, argv, &gWindow))
        return EXIT_FAILURE;


    // Create the mesh
    UCreateMesh(gMesh); // Calls the function to create the Vertex Buffer Object

    // Load and create shader program
    if (!UCreateShaderProgram(vertexShaderSource, fragmentShaderSource, shaderProgram))
        return EXIT_FAILURE;

    if (!UCreateShaderProgram(lampVertexShaderSource, lampFragmentShaderSource, lampProgram))
        return EXIT_FAILURE;

    // Load texture
    const char* textureFile1 = "art.jpg";
    const char* textureFile2 = "bottle_texture.jpg";
    const char* textureFile3 = "tiles.jpg";
    const char* textureFile4 = "wood.jpg";
    const char* textureFile5 = "stone.jpg";
    const char* textureFile6 = "cylinder.jpg";

    if (!UCreateTexture(textureFile1, texture1))
    {
        std::cout << "Failed to load texture1 " << textureFile1 << std::endl;
        return EXIT_FAILURE;
    }

    if (!UCreateTexture(textureFile2, texture2))
    {
        std::cout << "Failed to load texture2 " << textureFile2 << std::endl;
        return EXIT_FAILURE;
    }

    if (!UCreateTexture(textureFile3, texture3))
    {
        std::cout << "Failed to load texture3 " << textureFile3 << std::endl;
        return EXIT_FAILURE;
    }

    if (!UCreateTexture(textureFile4, texture4))
    {
        std::cout << "Failed to load texture4 " << textureFile4 << std::endl;
        return EXIT_FAILURE;
    }

    if (!UCreateTexture(textureFile5, texture5))
    {
        std::cout << "Failed to load texture5 " << textureFile5 << std::endl;
        return EXIT_FAILURE;
    }

    if (!UCreateTexture(textureFile6, texture6))
    {
        std::cout << "Failed to load texture6 " << textureFile6 << std::endl;
        return EXIT_FAILURE;
    }

    // Sets the background color of the window to black (it will be implicitely used by glClear)
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

    // render loop
    while (!glfwWindowShouldClose(gWindow))
    {
        // per-frame time logic
        float currentFrame = (float)glfwGetTime();
        deltaTime = currentFrame - lastFrame;
        lastFrame = currentFrame;

        // input
        UProcessInput(gWindow);

        // render
        URender(shaderProgram);

        glfwPollEvents();
    }

    // Prints to console vertices, normals, texture coordinates, and indices of a sphere using calculations from "UCalcSphere" function for easy copy/paste into arrays
    // Left the code here for future recalculation and to show where data comes from
    /*
    float u = 0.0f;
    float v = 0.0f;
    for (int i = 0; i < sphereVertices.size(); ++i) {
        u = (((sphereVertices[i].x) + 1) / 2);
        v = (((sphereVertices[i].y) + 1) / 2);
        std::cout << sphereVertices[i].x << "f, "  // x vertex
                  << sphereVertices[i].y << "f, "  // y vertex
                  << sphereVertices[i].z << "f, "  // z vertex
                  << sphereVertices[i].x << "f, "  // x normal
                  << sphereVertices[i].y << "f, "  // y normal
                  << sphereVertices[i].z << "f, "  // z normal
                  << u                   << "f, "  // x texture coord
                  << v                   << "f, "  // y texture coord
                  << std::endl;
    }

    int count;
    for (int i = 0; i < sphereIndices.size(); ++i) {
        std::cout << sphereIndices[i] + 189 << ", ";
        count = i + 1;
        if (count % 3 == 0)
        {
            std::cout << std::endl;
        }
    }
    */

    // Release mesh data
    UDestroyMesh(gMesh);

    // Release texture data
    UDestroyTexture(texture1);
    UDestroyTexture(texture2);
    UDestroyTexture(texture3);
    UDestroyTexture(texture4);
    UDestroyTexture(texture5);
    UDestroyTexture(texture6);

    // De-allocate resources
    glDeleteVertexArrays(1, &gMesh.vao);
    glDeleteBuffers(1, gMesh.vbos);
    glDeleteBuffers(1, gMesh.ebos);

    // Destroy shader programs
    UDestroyShaderProgram(shaderProgram);
    UDestroyShaderProgram(lampProgram);

    exit(EXIT_SUCCESS); // Terminates the program successfully
}


// Initialize GLFW, GLAD, and create a window
bool UInitialize(int argc, char* argv[], GLFWwindow * *window)
{

    // glfw: initialize and configure
    // ------------------------------
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    // glfw window creation
    // --------------------
    * window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT, SCR_TITLE, NULL, NULL);
    if (*window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return false;
    }

    glfwMakeContextCurrent(*window);
    glfwSetFramebufferSizeCallback(*window, framebuffer_size_callback);
    glfwSetCursorPosCallback(*window, mouse_callback);
    glfwSetScrollCallback(*window, scroll_callback);

    // tell GLFW to capture our mouse
    glfwSetInputMode(*window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    // glad: load all OpenGL function pointers
    // ---------------------------------------
    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
    {
        std::cout << "Failed to initialize GLAD" << std::endl;
        return false;
    }

    // Displays GPU OpenGL version
    std::cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << std::endl;

    return true;
}

// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
// ---------------------------------------------------------------------------------------------------------
void UProcessInput(GLFWwindow * window)
{
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);

    float cameraSpeed = 2.5f * deltaTime;
    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        cameraPos += cameraSpeed * cameraFront;
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        cameraPos -= cameraSpeed * cameraFront;
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        cameraPos -= glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        cameraPos += glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
        cameraPos += cameraSpeed * cameraUp;
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
        cameraPos -= cameraSpeed * cameraUp;

}

// glfw: whenever the window size changed (by OS or user resize) this callback function executes
// ---------------------------------------------------------------------------------------------
void framebuffer_size_callback(GLFWwindow * window, int width, int height)
{
    // make sure the viewport matches the new window dimensions; note that width and 
    // height will be significantly larger than specified on retina displays.
    glViewport(0, 0, width, height);
}

// glfw: whenever the mouse moves, this callback is called
// -------------------------------------------------------
void mouse_callback(GLFWwindow * window, double xpos, double ypos)
{
    if (firstMouse)
    {
        lastX = (float)xpos;
        lastY = (float)ypos;
        firstMouse = false;
    }

    float xoffset = (float)xpos - lastX;
    float yoffset = lastY - (float)ypos; // reversed since y-coordinates go from bottom to top
    lastX = (float)xpos;
    lastY = (float)ypos;

    float sensitivity = 0.1f; // change this value to your liking
    xoffset *= sensitivity;
    yoffset *= sensitivity;

    yaw += xoffset;
    pitch += yoffset;

    // make sure that when pitch is out of bounds, screen doesn't get flipped
    if (pitch > 89.0f)
        pitch = 89.0f;
    if (pitch < -89.0f)
        pitch = -89.0f;

    glm::vec3 front;
    front.x = cos(glm::radians(yaw)) * cos(glm::radians(pitch));
    front.y = sin(glm::radians(pitch));
    front.z = sin(glm::radians(yaw)) * cos(glm::radians(pitch));
    cameraFront = glm::normalize(front);
}

// glfw: whenever the mouse scroll wheel scrolls, this callback is called
// ----------------------------------------------------------------------
void scroll_callback(GLFWwindow * window, double xoffset, double yoffset)
{
    processMouseScroll((float)yoffset, (float)deltaTime);
}

void processMouseScroll(float yoffset, float deltaTime)
{
    double MovementSpeed = 25.0f;

    MovementSpeed += yoffset * deltaTime;
    if (MovementSpeed < 1.0f)
        MovementSpeed = 1.0f;
    if (MovementSpeed > 25.0f)
        MovementSpeed = 25.0f;
}

void UResizeWindow(GLFWwindow * window, int width, int height)
{
    glViewport(0, 0, width, height);
}

void URender(GLuint shaderProgram)
{

    // configure global opengl state
    // -----------------------------
    glEnable(GL_DEPTH_TEST);

    //render
    // -----------------------------
    glClearColor(0.1f, 0.1f, 0.1f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // Set the shader to be used
    glUseProgram(shaderProgram);

    // camera/view transformation
    glm::mat4 view = glm::lookAt(cameraPos, cameraPos + cameraFront, cameraUp);
    const glm::vec3 cameraPosition = cameraPos;
    // pass projection matrix to shader (note that in this case it could change every frame)
    glm::mat4 projection = glm::perspective(glm::radians(fov), (float)SCR_WIDTH / (float)SCR_HEIGHT, 0.1f, 100.0f);
    // calculate the model matrix for each object and pass it to shader before drawing
    // 1. Scales the object by 1
    glm::mat4 scale = glm::scale(glm::vec3(1.0f, 1.0f, 1.0f));
    // 2. Rotates shape by 15 degrees in the x axis
    glm::mat4 rotation = glm::rotate(0.0f, glm::vec3(1.0, 1.0f, 1.0f));
    // 3. Place object at the origin
    glm::mat4 translation = glm::translate(glm::vec3(0.0f, 0.0f, 0.0f));
    // 4. Place model based on translation and scale
    glm::mat4 model = glm::translate(gPosition) * glm::scale(gScale);

    // Retrieve, pass, and reference uniform matrices to the shader program
    UPassTransformMatrices(model, view, projection, cameraPosition, shaderProgram, gLightPosition1, 1.0f, 1.0f, 1.0f);

    // Activates shader program
    glUseProgram(shaderProgram);
    // Binds texture to vertex array object
    glBindVertexArray(gMesh.vao);

    // Draw and texture pyramid between rectangular cube and small cube
    GLint textureLoc1 = glGetUniformLocation(shaderProgram, "texture1");
    UDrawObjectWithTexture(textureLoc1, texture1, 0, gMesh.pyramidIndices);
    // Draw and texture bottle, aka rectangular cube
    GLint textureLoc2 = glGetUniformLocation(shaderProgram, "texture2");
    UDrawObjectWithTexture(textureLoc2, texture2, 1, gMesh.bottleIndices);
    // Draw and texture bottle cap, aka small cube on top of pyramid
    GLint textureLoc3 = glGetUniformLocation(shaderProgram, "texture3");
    UDrawObjectWithTexture(textureLoc3, texture3, 2, gMesh.capIndices);
    // Draw and texture table top, aka plane
    GLint textureLoc4 = glGetUniformLocation(shaderProgram, "texture4");
    UDrawObjectWithTexture(textureLoc4, texture4, 3, gMesh.planeIndices);

    model = glm::translate(gSpherePosition) * glm::scale(gScale);
    UPassTransformMatrices(model, view, projection, cameraPosition, shaderProgram, gLightPosition1, 1.0f, 1.0f, 1.0f);
    GLint textureLoc5 = glGetUniformLocation(shaderProgram, "texture5");
    UDrawObjectWithTexture(textureLoc5, texture5, 4, gMesh.sphereIndices);

    model = glm::translate(gCupPosition) * glm::scale(gScale);
    UPassTransformMatrices(model, view, projection, cameraPosition, shaderProgram, gLightPosition2, 0.8f, 0.6f, 0.8f);
    GLint textureLoc6 = glGetUniformLocation(shaderProgram, "texture6");
    UDrawObjectWithTexture(textureLoc6, texture6, 5, gMesh.cupIndices);

    // LAMPS: draw lamps
    //----------------
    glUseProgram(lampProgram);
    glBindVertexArray(gMesh.vao);

    // LIGHT SOURCE 1 ----------------------------------------------------
    //Transform the smaller cube used as a visual que for the light source
    model = glm::translate(gLightPosition1) * glm::scale(gLightScale);

    // Retrieve, pass, and reference uniform matrices to the shader program
    UPassTransformMatrices(model, view, projection, cameraPosition, shaderProgram, gLightPosition1, 1.0f, 1.0f, 1.0f);
    UPassUniformLampMatrices(model, view, projection, lampProgram);


    // Draws the light source using indices from bottle cap, aka small cube
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, gMesh.ebos[2]);
    glDrawElements(GL_TRIANGLES, gMesh.capIndices, GL_UNSIGNED_SHORT, NULL);
    //---------------------------------------------------------------------

   
    // LIGHT SOURCE 2 ----------------------------------------------------
    //Transform the smaller cube used as a visual que for the light source
    model = glm::translate(gLightPosition2) * glm::scale(gLightScale);

    // Retrieve, pass, and reference uniform matrices to the shader program
    UPassTransformMatrices(model, view, projection, cameraPosition, shaderProgram, gLightPosition2, 1.0f, 1.0f, 1.0f);
    UPassUniformLampMatrices(model, view, projection, lampProgram);


    // Draws the light source using indices from bottle cap, aka small cube
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, gMesh.ebos[2]);
    glDrawElements(GL_TRIANGLES, gMesh.capIndices, GL_UNSIGNED_SHORT, NULL);
    //---------------------------------------------------------------------



    // Unbind vertex array object, unbind element array buffer object, unbind texture, de-activate shader program
    glBindVertexArray(0);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
    UnbindTexture();
    glUseProgram(0);

    // glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
    glfwSwapBuffers(gWindow); // Flips the the back buffer with the front buffer every frame
}

// bind textures on corresponding texture units
void UBindTexture(GLint loc, GLuint & textureId)
{
    // Selects texture unit
    glActiveTexture(GL_TEXTURE0);
    // Binds given texture id to target
    glBindTexture(GL_TEXTURE_2D, textureId);
    // texture locations for shader
    USetUniform(loc, 0);
}

// Unbinds texture by setting target to zero
void UnbindTexture()
{
    glBindTexture(GL_TEXTURE_2D, 0);
}

// Activates shader program and sets texture location to texture unit, texture unit is always 0 in this scene
void USetUniform(GLint loc, GLint unit)
{
    glUseProgram(shaderProgram);
    glUniform1i(loc, unit);
}

// Draws an object and textures that object based on indices from corresponding EBO and binded texture id
void UDrawObjectWithTexture(GLint loc, GLuint & txtrId, GLint ebo, GLuint indices)
{
    UBindTexture(loc, txtrId);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, gMesh.ebos[ebo]);
    glDrawElements(GL_TRIANGLES, indices, GL_UNSIGNED_SHORT, NULL);
}

// Retrieve, pass, and reference uniform matrices to the shader program
void UPassTransformMatrices(glm::mat4 model, glm::mat4 view, glm::mat4 projection, glm::vec3 camPos, GLuint shader, glm::vec3 lightPos, float lightR, float lightG, float lightB)
{
    // Retrieves and passes transform matrices to the Shader program
    GLint modelLoc = glGetUniformLocation(shaderProgram, "model");
    GLint viewLoc = glGetUniformLocation(shaderProgram, "view");
    GLint projLoc = glGetUniformLocation(shaderProgram, "projection");

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Reference matrix uniforms from the Shader program for the object color, light color, light position, and camera position
    GLint objectColorLoc = glGetUniformLocation(shaderProgram, "objectColor");
    GLint lightColorLoc = glGetUniformLocation(shaderProgram, "lightColor");
    GLint lightPositionLoc = glGetUniformLocation(shaderProgram, "lightPos");
    GLint viewPositionLoc = glGetUniformLocation(shaderProgram, "viewPosition");

    // Pass color, light, and camera data to the Cube Shader program's corresponding uniforms
    glUniform3f(objectColorLoc, 1.0f, 1.0f, 1.0f);
    glUniform3f(lightColorLoc, lightR, lightG, lightB);
    glUniform3f(lightPositionLoc, lightPos.x, lightPos.y, lightPos.z);
    glUniform3f(viewPositionLoc, camPos.x, camPos.y, camPos.z);

    GLint UVScaleLoc = glGetUniformLocation(shaderProgram, "uvScale");
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));
}

// Retrieve, pass, and reference uniform matrices to the shader program
void UPassUniformLampMatrices(glm::mat4 model, glm::mat4 view, glm::mat4 projection, GLuint lampshader)
{
    // Reference matrix uniforms from the Lamp Shader program
    GLint modelLoc = glGetUniformLocation(lampshader, "model");
    GLint viewLoc = glGetUniformLocation(lampshader, "view");
    GLint projLoc = glGetUniformLocation(lampshader, "projection");

    // Pass matrix data to the Lamp Shader program's matrix uniforms
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));
}

// Calculates a sphere
void UCalcSphere(int stacks, int slices, float radius)
{
    // Adapted code used here: https://stackoverflow.com/questions/26116923/modern-opengl-draw-a-sphere-and-cylinder
    // Calc The Vertices
    for (int i = 0; i <= stacks; ++i) {

        float V = i / (float)stacks;
        float phi = V * glm::pi <float>();

        // Loop Through Slices
        for (int j = 0; j <= slices; ++j) {

            float U = j / (float)slices;
            float theta = U * (glm::pi <float>() * 2);
            
            // Calc The Vertex Positions
            float x = cosf(theta) * sinf(phi);
            float y = cosf(phi);
            float z = sinf(theta) * sinf(phi);

            // Push Back Vertex Data
            sphereVertices.push_back(glm::vec3(x, y, z) * radius);
        }
    }

    // Calc The Index Positions
    for (int i = 0; i < slices * stacks + slices; ++i) {

        sphereIndices.push_back(i);
        sphereIndices.push_back(i + slices + 1);
        sphereIndices.push_back(i + slices);
                                    
        sphereIndices.push_back(i + slices + 1);
        sphereIndices.push_back(i);
        sphereIndices.push_back(i + 1);
    }
}























































































































